#include <stdio.h>

typedef struct _carta {
  char face[3];
  char naipe;
  int valor;
  char nome[30];
} tCarta;

typedef struct _lista {
  tCarta carta;
  void *prox;
} tNo;

int sorteaCarta(int tamanhoLista);

tNo *criaListaCartas();

tNo *CriaNoLista(tCarta carta);

void insereNoPosLista(tNo **lista, tNo *novoNo, int pos);

int listaVazia(tNo *lista);

tNo *removeCartaNaLista(tNo **lista, int pos);

tCarta getElemLista(tNo *lista);

tNo *acessaCartaNaLista(tNo *lista, int pos);

int verificaSequencia(tCarta carta);

int calculaPontuacao(tNo *listaDescartes, int quantidadeDescarte);

void reposicionaCartaNaLista(tNo **lista, int posInicial, int posFinal);

void liberaListaCartas(tNo **lista);

void imprimeListaCartas(tNo *lista);
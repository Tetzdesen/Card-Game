#include "carta.h"
#include <stdio.h>



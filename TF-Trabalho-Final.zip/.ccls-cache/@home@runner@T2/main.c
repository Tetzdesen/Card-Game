/*
T2 - Segunda entrega do trabalho

Integrantes:
1. Gabriel Tetzner Menegueti (2022200525)
2. Adler Amorim de Sousa (2022201426)
3. Isaías C Altoé (2022201151)

Data: 20/10/2023

*/

// main.c

// Includes

#include "listacartas.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Função que sorteia um número dependendo do tamanho da lista.
int sorteiaNumero(int tamanhoLista) { return (rand() % tamanhoLista) + 1; }

// Função para calcular a pontuação de descarte.
int calculaPontuacao(tNo *listaDescartes, int qtdDescarte) {

  tNo *anterior, *proximo, *aux1, *aux2, *aux3;

  anterior = listaDescartes;

   if (qtdDescarte == 1) return 0;
   else if (qtdDescarte == 2) {
  
      proximo = anterior->prox;
  
      if (strcmp((anterior->carta).face, (proximo->carta).face) == 0) return 2;
  
      if ((anterior->carta).naipe == (proximo->carta).naipe) return 6;
  
      if (((anterior->carta).valor + 1) == (proximo->carta).valor) return 4;
  
    } 
    else if (qtdDescarte == 3) {
  
      proximo = anterior->prox;
      aux1 = proximo->prox;
  
      if ((strcmp(anterior->carta.face, proximo->carta.face) == 0) &&
          (strcmp(proximo->carta.face, aux1->carta.face) == 0)) return 5;
  
      if ((anterior->carta.naipe == proximo->carta.naipe) &&
          (proximo->carta.naipe == aux1->carta.naipe)) return 9;
  
      if (((anterior->carta).valor + 1) == (proximo->carta).valor &&
          ((proximo->carta).valor + 1) == (aux1->carta).valor) return 6;
      
    } 
    else if (qtdDescarte == 4) {
  
      proximo = anterior->prox;
      aux1 = proximo->prox;
      aux2 = aux1->prox;
  
      if ((strcmp(anterior->carta.face, proximo->carta.face) == 0) &&
          (strcmp(proximo->carta.face, aux1->carta.face) == 0) &&
          (strcmp(aux1->carta.face, aux2->carta.face) == 0)) return 20;
  
      if ((anterior->carta.naipe == proximo->carta.naipe) &&
          (proximo->carta.naipe == aux1->carta.naipe) &&
          (aux1->carta.naipe == aux2->carta.naipe)) return 12;
  
      if (((anterior->carta).valor + 1) == (proximo->carta).valor &&
          ((proximo->carta).valor + 1) == (aux1->carta).valor &&
          ((aux1->carta).valor + 1) == (aux2->carta).valor) return 8;
      
    } 
    else if (qtdDescarte == 5) {
  
      proximo = anterior->prox;
      aux1 = proximo->prox;
      aux2 = aux1->prox;
      aux3 = aux2->prox;
  
      if ((anterior->carta.naipe == proximo->carta.naipe) &&
          (proximo->carta.naipe == aux1->carta.naipe) &&
          (aux1->carta.naipe == aux2->carta.naipe) &&
          (aux2->carta.naipe == aux3->carta.naipe)) return 15;
  
      if (((anterior->carta).valor + 1) == (proximo->carta).valor &&
          ((proximo->carta).valor + 1) == (aux1->carta).valor &&
          ((aux1->carta).valor + 1) == (aux2->carta).valor &&
          ((aux2->carta).valor + 1) == (aux3->carta).valor) return 10;
    }

  return 0;
}

// Main

int main(void) {

  srand(time(NULL));

  // Variáveis do tipo int
  int i, opcao1, opcao2, posOrigem, posDestino, quantDescartes,
      contadorDescartes = 0, tamanhoMonte = 52, tamanhoMao = 5;

  // Variável carta;
  tCarta carta;

  // tNo Variáveis
  tNo *monte, *mao, *descartes;

  // Declarando arquivo
  FILE *file;

  // Abrindo o arquivo para leitura
  file = fopen("baralho1.dat", "r");

  // Erro de leitura
  if (file == NULL) {
    printf(
        "O arquivo não foi aberto para leitura, por causa de algum erro (pode ser o nome do arquivo). \n");
    return 0;
  }

  // Menu
  printf("\n MENU:\n\n 1 - INICIAR JOGO (SORTEAR 5 CARTAS)\n\n 2 - SAIR\n\n "
         "Digite a "
         "opção: ");
  scanf("%d", &opcao1);

  switch (opcao1) {

  case 1: // Inicia o jogo (cria as listas)

    monte = criaListaCartas();
    mao = criaListaCartas();
    descartes = criaListaCartas();

    // Insere as cartas do arquivo na lista
    for (i = 1; i <= tamanhoMonte; i++) {
      fscanf(file, "%s %c %d %[^\n]s", carta.face, &carta.naipe, &carta.valor,
             carta.nome);
      insereNoPosListaCartas(&monte, CriaNoListaCartas(carta), i);
    }

    // fecha arquivo
    fclose(file);

    printf("\n");
    for (i = 1; i <= 5; i++) {
      insereNoPosListaCartas(
          &mao, removeNaListaCartas(&monte, sorteiaNumero(tamanhoMonte)), i);
      tamanhoMonte--;
    }

    printf(" Foram sorteadas %d cartas do seu monte.\n\n", 5);

    // Looping para reposicionamento/descarte de cartas

    do {

      printf(" Monte (%2d)                              Descarte (%2d)\n",
             tamanhoMonte, contadorDescartes);
      printf("\n      ");
      if (tamanhoMao != 0) {
        imprimeListaCartas(mao);
        printf("\n Mao  :");
        for (i = 1; i <= tamanhoMao; i++) {
          printf("   %-3d   ", i);
        }
        printf("\n");

      } else {
        printf("\n Mao :");
        imprimeListaCartas(mao);
      }

      printf("\n MENU: \n\n 1 - Reposicionar carta \n 2 - Descartar "
             "cartas \n 3 - Sair do jogo \n\n Digite sua opção: ");

      scanf("%d", &opcao2);

      switch (opcao2) {

      // Reposicionamento de cartas
      case 1:

        printf("\n Digite a posição de origem na mão: ");
        scanf("%d", &posOrigem);

        printf("\n Digite a posição de destino na mão: ");
        scanf("%d", &posDestino);

        if ((posOrigem > 0 && posOrigem <= tamanhoMao) &&
            (posDestino > 0 && posDestino <= tamanhoMao))
          reposicionaNaListaCartas(&mao, posOrigem, posDestino);
        else
          printf("\n Você digitou uma posição que não existe, tente novamente. "
                 "\n");

        printf("\n");

        break;

      // Descarte de cartas
      case 2:
        printf("\n Digite a quantidade de cartas que você deseja descartar: ");
        scanf("%d", &quantDescartes);

        if ((quantDescartes > 0 && quantDescartes <= tamanhoMao)) {
          contadorDescartes += quantDescartes;
          for (i = 1; i <= quantDescartes; i++) {
            insereNoPosListaCartas(&descartes, removeNaListaCartas(&mao, 1), i);
            tamanhoMao--;
          }

          printf("\n A pontuação de bônus do seu descarte é: %d pontos\n\n",
                 calculaPontuacao(descartes, quantDescartes));
        } else
          printf("\n Você digitou uma quantidade de cartas que não existe, "
                 "tente novamente. \n\n");
        break;
      case 3:
        liberaListaCartas(&monte);
        liberaListaCartas(&mao);
        liberaListaCartas(&descartes);
        printf("\n Você encerrou o jogo (Monte e mão liberadas). \n");
        break;
      default:
        printf("\n Opção inválida, digite novamente.\n\n");
        break;
      }
    } while (opcao2 != 3);
    break;
  // Case que encerra o jogo, caso a pessoa decida não começar
  case 2:
    printf("\nVocê encerrou o jogo. \n");
    break;
  default:
    printf("\nOpção inválida, reinicie o jogo.\n");
    break;
  }

  return 0;
}